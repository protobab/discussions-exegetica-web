import { useState } from "react";

const COLORS = {
  navy: "#1B2A4A",
  parchment: "#F7F3EB",
  gold: "#C9A84C",
  sage: "#7A9E7E",
  mist: "#EEF2F7",
  navyLight: "#2E4270",
  goldLight: "#E8C97A",
  text: "#2C2C2C",
  textMuted: "#6B7280",
};

const FONTS = {
  display: "'Playfair Display', Georgia, serif",
  body: "'Inter', system-ui, sans-serif",
};

const style = (obj) => obj;

// ── DATA ────────────────────────────────────────────────────────────────────

const dailyWord = {
  reference: "John 1:1",
  text: "In the beginning was the Word, and the Word was with God, and the Word was God.",
  theme: "The Nature of Christ",
};

const categories = [
  { id: "all", label: "All Topics", icon: "✦" },
  { id: "exegesis", label: "Deep Dive", icon: "📖" },
  { id: "seekers", label: "Seekers' Corner", icon: "🌱" },
  { id: "prayer", label: "Prayer & Life", icon: "🙏" },
  { id: "prophecy", label: "Prophecy", icon: "🕊️" },
  { id: "theology", label: "Theology", icon: "⚡" },
];

const threads = [
  {
    id: 1,
    category: "exegesis",
    categoryLabel: "Deep Dive",
    title: "What does 'logos' really mean in John 1:1? A word-by-word breakdown",
    excerpt:
      "The Greek word logos carries far more than our English 'Word'. It spans reason, divine order, and creative power. Let's unpack it together across cultural and historical context...",
    author: "Emmanuel O.",
    avatar: "EO",
    avatarColor: "#7A9E7E",
    replies: 47,
    views: 1204,
    likes: 93,
    timeAgo: "2 hours ago",
    badge: "Elder",
    badgeColor: COLORS.gold,
    pinned: true,
  },
  {
    id: 2,
    category: "seekers",
    categoryLabel: "Seekers' Corner",
    title: "I'm not sure God is real — but I want to believe. Where do I start?",
    excerpt:
      "No judgement here — I grew up in a non-religious home and something keeps drawing me to explore faith. Can someone walk me through the basics without the jargon?",
    author: "Priya M.",
    avatar: "PM",
    avatarColor: "#C9A84C",
    replies: 62,
    views: 2891,
    likes: 188,
    timeAgo: "5 hours ago",
    badge: "Seeker",
    badgeColor: "#A78BFA",
    pinned: false,
  },
  {
    id: 3,
    category: "theology",
    categoryLabel: "Theology",
    title: "Grace vs works: Are Paul and James actually contradicting each other?",
    excerpt:
      "Romans 3:28 and James 2:24 seem to say opposite things. This tension has shaped entire denominations. Let's dig into the original texts and historical context...",
    author: "Rev. Adaeze K.",
    avatar: "AK",
    avatarColor: "#1B2A4A",
    replies: 34,
    views: 876,
    likes: 71,
    timeAgo: "Yesterday",
    badge: "Teacher",
    badgeColor: "#EF4444",
    pinned: false,
  },
  {
    id: 4,
    category: "prayer",
    categoryLabel: "Prayer & Life",
    title: "How do you pray when you feel spiritually dry? Share your practices",
    excerpt:
      "Seasons of dryness are real and every believer faces them. What has helped you maintain connection with God when prayer feels hollow or distant?",
    author: "Grace T.",
    avatar: "GT",
    avatarColor: "#2E4270",
    replies: 89,
    views: 3102,
    likes: 214,
    timeAgo: "Yesterday",
    badge: "Disciple",
    badgeColor: "#3B82F6",
    pinned: false,
  },
  {
    id: 5,
    category: "prophecy",
    categoryLabel: "Prophecy",
    title: "Isaiah 53 — prophecy of Christ or something else? A careful reading",
    excerpt:
      "This passage is cited more than almost any other in the NT as pointing to Jesus. But what did it mean to its original hearers? And how should we read it today?",
    author: "Daniel F.",
    avatar: "DF",
    avatarColor: "#7A9E7E",
    replies: 28,
    views: 654,
    likes: 55,
    timeAgo: "2 days ago",
    badge: "Elder",
    badgeColor: COLORS.gold,
    pinned: false,
  },
  {
    id: 6,
    category: "exegesis",
    categoryLabel: "Deep Dive",
    title: "The Beatitudes — radical reversals in Matthew 5:3–12",
    excerpt:
      "Blessed are the poor in spirit? The meek? Jesus flips the world's values upside down. How does each beatitude challenge our modern assumptions about success and worth?",
    author: "Mary-Jo A.",
    avatar: "MJ",
    avatarColor: "#C9A84C",
    replies: 41,
    views: 987,
    likes: 102,
    timeAgo: "3 days ago",
    badge: "Teacher",
    badgeColor: "#EF4444",
    pinned: false,
  },
];

// ── COMPONENTS ───────────────────────────────────────────────────────────────

function Avatar({ initials, color, size = 38 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: color,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#fff",
        fontFamily: FONTS.body,
        fontSize: size * 0.35,
        fontWeight: 600,
        flexShrink: 0,
        letterSpacing: "0.02em",
      }}
    >
      {initials}
    </div>
  );
}

function Badge({ label, color }) {
  return (
    <span
      style={{
        background: color + "22",
        color: color,
        border: `1px solid ${color}55`,
        borderRadius: 4,
        padding: "1px 7px",
        fontSize: 10,
        fontFamily: FONTS.body,
        fontWeight: 600,
        letterSpacing: "0.06em",
        textTransform: "uppercase",
      }}
    >
      {label}
    </span>
  );
}

function CircleLogo({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none">
      <circle cx="18" cy="18" r="16" stroke={COLORS.gold} strokeWidth="2" />
      <circle cx="18" cy="18" r="9" stroke={COLORS.gold} strokeWidth="1.5" strokeDasharray="3 2" />
      <circle cx="18" cy="18" r="3.5" fill={COLORS.gold} />
      <path d="M18 2 A16 16 0 0 1 34 18" stroke={COLORS.goldLight} strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

function ThreadCard({ thread, onClick }) {
  const [liked, setLiked] = useState(false);
  return (
    <div
      onClick={() => onClick(thread)}
      style={{
        background: "#fff",
        border: `1px solid ${thread.pinned ? COLORS.gold + "55" : "#E5E7EB"}`,
        borderRadius: 12,
        padding: "20px 22px",
        cursor: "pointer",
        transition: "box-shadow 0.18s, transform 0.18s",
        boxShadow: thread.pinned
          ? `0 0 0 1px ${COLORS.gold}33, 0 2px 8px rgba(0,0,0,0.06)`
          : "0 1px 4px rgba(0,0,0,0.05)",
        position: "relative",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = "0 6px 24px rgba(27,42,74,0.12)";
        e.currentTarget.style.transform = "translateY(-2px)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = thread.pinned
          ? `0 0 0 1px ${COLORS.gold}33, 0 2px 8px rgba(0,0,0,0.06)`
          : "0 1px 4px rgba(0,0,0,0.05)";
        e.currentTarget.style.transform = "translateY(0)";
      }}
    >
      {thread.pinned && (
        <div
          style={{
            position: "absolute",
            top: 12,
            right: 14,
            fontSize: 10,
            color: COLORS.gold,
            fontFamily: FONTS.body,
            fontWeight: 700,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          📌 Featured
        </div>
      )}
      <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 10 }}>
        <span
          style={{
            background: COLORS.mist,
            color: COLORS.navyLight,
            borderRadius: 6,
            padding: "2px 9px",
            fontSize: 11,
            fontFamily: FONTS.body,
            fontWeight: 600,
          }}
        >
          {thread.categoryLabel}
        </span>
      </div>
      <h3
        style={{
          fontFamily: FONTS.display,
          fontSize: 17,
          fontWeight: 700,
          color: COLORS.navy,
          margin: "0 0 8px 0",
          lineHeight: 1.35,
        }}
      >
        {thread.title}
      </h3>
      <p
        style={{
          fontFamily: FONTS.body,
          fontSize: 13.5,
          color: COLORS.textMuted,
          margin: "0 0 14px 0",
          lineHeight: 1.6,
        }}
      >
        {thread.excerpt}
      </p>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Avatar initials={thread.avatar} color={thread.avatarColor} size={28} />
          <span style={{ fontFamily: FONTS.body, fontSize: 12.5, color: COLORS.text, fontWeight: 500 }}>
            {thread.author}
          </span>
          <Badge label={thread.badge} color={thread.badgeColor} />
          <span style={{ fontFamily: FONTS.body, fontSize: 11.5, color: COLORS.textMuted }}>{thread.timeAgo}</span>
        </div>
        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <span
            style={{ fontFamily: FONTS.body, fontSize: 12, color: COLORS.textMuted, cursor: "pointer" }}
            onClick={(e) => {
              e.stopPropagation();
              setLiked(!liked);
            }}
          >
            {liked ? "❤️" : "🤍"} {thread.likes + (liked ? 1 : 0)}
          </span>
          <span style={{ fontFamily: FONTS.body, fontSize: 12, color: COLORS.textMuted }}>
            💬 {thread.replies}
          </span>
          <span style={{ fontFamily: FONTS.body, fontSize: 12, color: COLORS.textMuted }}>
            👁 {thread.views.toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
}

function ThreadView({ thread, onBack }) {
  const [reply, setReply] = useState("");
  const [posted, setPosted] = useState(false);

  return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: "0 0 60px" }}>
      <button
        onClick={onBack}
        style={{
          background: "none",
          border: "none",
          color: COLORS.navyLight,
          fontFamily: FONTS.body,
          fontSize: 13.5,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 6,
          marginBottom: 24,
          padding: 0,
          fontWeight: 600,
        }}
      >
        ← Back to Forum
      </button>

      <div style={{ background: "#fff", borderRadius: 14, padding: "28px 32px", marginBottom: 20, border: `1px solid #E5E7EB` }}>
        <span
          style={{
            background: COLORS.mist,
            color: COLORS.navyLight,
            borderRadius: 6,
            padding: "2px 9px",
            fontSize: 11,
            fontFamily: FONTS.body,
            fontWeight: 600,
            display: "inline-block",
            marginBottom: 14,
          }}
        >
          {thread.categoryLabel}
        </span>
        <h1
          style={{
            fontFamily: FONTS.display,
            fontSize: 24,
            fontWeight: 700,
            color: COLORS.navy,
            margin: "0 0 16px",
            lineHeight: 1.3,
          }}
        >
          {thread.title}
        </h1>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
          <Avatar initials={thread.avatar} color={thread.avatarColor} size={38} />
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontFamily: FONTS.body, fontSize: 13.5, fontWeight: 600, color: COLORS.text }}>
                {thread.author}
              </span>
              <Badge label={thread.badge} color={thread.badgeColor} />
            </div>
            <span style={{ fontFamily: FONTS.body, fontSize: 12, color: COLORS.textMuted }}>{thread.timeAgo}</span>
          </div>
        </div>
        <p style={{ fontFamily: FONTS.body, fontSize: 15, color: COLORS.text, lineHeight: 1.75, margin: 0 }}>
          {thread.excerpt}
          {" "}This is a living discussion — your insight, questions, and reflections are welcome here. There are no wrong perspectives, only honest ones. Let the Word speak to us together.
        </p>
      </div>

      {/* Sample replies */}
      {[
        { name: "Daniel F.", init: "DF", col: "#7A9E7E", badge: "Elder", bc: COLORS.gold, time: "1 hour ago", text: "Beautifully framed. I'd add that the Septuagint usage of this term in Proverbs 8 is crucial context here — Wisdom personified as a creative agent alongside God. The connection to Johannine logos is undeniable." },
        { name: "Priya M.", init: "PM", col: "#C9A84C", badge: "Seeker", bc: "#A78BFA", time: "45 min ago", text: "As someone new to all of this — thank you for making it accessible. Can someone explain what Septuagint means? I don't want to get lost." },
      ].map((r, i) => (
        <div
          key={i}
          style={{
            background: "#fff",
            borderRadius: 10,
            padding: "18px 22px",
            marginBottom: 12,
            border: "1px solid #E5E7EB",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Avatar initials={r.init} color={r.col} size={30} />
            <span style={{ fontFamily: FONTS.body, fontSize: 13, fontWeight: 600, color: COLORS.text }}>{r.name}</span>
            <Badge label={r.badge} color={r.bc} />
            <span style={{ fontFamily: FONTS.body, fontSize: 11.5, color: COLORS.textMuted }}>{r.time}</span>
          </div>
          <p style={{ fontFamily: FONTS.body, fontSize: 14, color: COLORS.text, lineHeight: 1.7, margin: 0 }}>{r.text}</p>
        </div>
      ))}

      {/* Reply box */}
      <div style={{ background: "#fff", borderRadius: 12, padding: "20px 22px", border: `1px solid #E5E7EB`, marginTop: 20 }}>
        <p style={{ fontFamily: FONTS.display, fontSize: 15, fontWeight: 700, color: COLORS.navy, margin: "0 0 12px" }}>
          Add your voice
        </p>
        {posted ? (
          <div style={{ color: COLORS.sage, fontFamily: FONTS.body, fontSize: 14, fontWeight: 600, padding: "12px 0" }}>
            ✓ Your reply has been shared with the Circle.
          </div>
        ) : (
          <>
            <textarea
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              placeholder="Share your reflection, question, or insight…"
              style={{
                width: "100%",
                minHeight: 100,
                border: `1.5px solid #D1D5DB`,
                borderRadius: 8,
                padding: "12px 14px",
                fontFamily: FONTS.body,
                fontSize: 14,
                color: COLORS.text,
                resize: "vertical",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
            <button
              onClick={() => reply.trim() && setPosted(true)}
              style={{
                marginTop: 10,
                background: COLORS.navy,
                color: "#fff",
                border: "none",
                borderRadius: 8,
                padding: "10px 22px",
                fontFamily: FONTS.body,
                fontSize: 13.5,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Post to Circle
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ── MAIN APP ─────────────────────────────────────────────────────────────────

export default function DiscussionsExegetica() {
  const [page, setPage] = useState("home"); // 'home' | 'forum' | 'thread'
  const [activeCategory, setActiveCategory] = useState("all");
  const [activeThread, setActiveThread] = useState(null);
  const [searchVal, setSearchVal] = useState("");

  const filteredThreads = threads.filter((t) => {
    const matchCat = activeCategory === "all" || t.category === activeCategory;
    const matchSearch =
      !searchVal ||
      t.title.toLowerCase().includes(searchVal.toLowerCase()) ||
      t.excerpt.toLowerCase().includes(searchVal.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div style={{ fontFamily: FONTS.body, background: COLORS.parchment, minHeight: "100vh" }}>
      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${COLORS.parchment}; }
        ::-webkit-scrollbar-thumb { background: ${COLORS.gold}88; border-radius: 3px; }
        textarea:focus { border-color: ${COLORS.gold} !important; }
      `}</style>

      {/* ── NAV ── */}
      <nav
        style={{
          background: COLORS.navy,
          padding: "0 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 60,
          position: "sticky",
          top: 0,
          zIndex: 100,
          boxShadow: "0 2px 12px rgba(0,0,0,0.15)",
        }}
      >
        <div
          onClick={() => setPage("home")}
          style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}
        >
          <CircleLogo size={34} />
          <span
            style={{
              fontFamily: FONTS.display,
              fontSize: 20,
              fontWeight: 700,
              color: "#fff",
              letterSpacing: "-0.01em",
            }}
          >
            Discussions <span style={{ color: COLORS.gold }}>Exegetica</span>
          </span>
        </div>

        <div style={{ display: "flex", gap: 6 }}>
          {["Home", "Forum", "Daily Word", "Study Groups"].map((item) => (
            <button
              key={item}
              onClick={() => {
                if (item === "Forum") setPage("forum");
                else if (item === "Home") setPage("home");
              }}
              style={{
                background:
                  (item === "Home" && page === "home") || (item === "Forum" && (page === "forum" || page === "thread"))
                    ? COLORS.gold + "22"
                    : "none",
                border: "none",
                color:
                  (item === "Home" && page === "home") || (item === "Forum" && (page === "forum" || page === "thread"))
                    ? COLORS.gold
                    : "rgba(255,255,255,0.75)",
                fontFamily: FONTS.body,
                fontSize: 13.5,
                fontWeight: 500,
                padding: "6px 14px",
                borderRadius: 6,
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              {item}
            </button>
          ))}
        </div>

        <button
          style={{
            background: COLORS.gold,
            color: COLORS.navy,
            border: "none",
            borderRadius: 8,
            padding: "8px 18px",
            fontFamily: FONTS.body,
            fontSize: 13,
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Join Circle
        </button>
      </nav>

      {/* ── HOME PAGE ── */}
      {page === "home" && (
        <div>
          {/* Hero */}
          <div
            style={{
              background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.navyLight} 100%)`,
              padding: "80px 32px 70px",
              textAlign: "center",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Decorative circles */}
            {[180, 320, 480].map((r, i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: r,
                  height: r,
                  borderRadius: "50%",
                  border: `1px solid ${COLORS.gold}${["18", "10", "08"][i]}`,
                  pointerEvents: "none",
                }}
              />
            ))}

            <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}>
              <CircleLogo size={56} />
            </div>

            <h1
              style={{
                fontFamily: FONTS.display,
                fontSize: "clamp(32px, 5vw, 52px)",
                fontWeight: 900,
                color: "#fff",
                margin: "0 0 16px",
                lineHeight: 1.15,
                position: "relative",
              }}
            >
              Where the Word is<br />
              <span style={{ color: COLORS.gold }}>opened together.</span>
            </h1>

            <p
              style={{
                fontFamily: FONTS.body,
                fontSize: 17,
                color: "rgba(255,255,255,0.72)",
                maxWidth: 520,
                margin: "0 auto 36px",
                lineHeight: 1.7,
              }}
            >
              A global community for seekers and believers — asking honest questions,
              studying Scripture deeply, and walking in the light of Christ.
            </p>

            <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
              <button
                onClick={() => setPage("forum")}
                style={{
                  background: COLORS.gold,
                  color: COLORS.navy,
                  border: "none",
                  borderRadius: 10,
                  padding: "13px 28px",
                  fontFamily: FONTS.body,
                  fontSize: 15,
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Enter the Forum
              </button>
              <button
                style={{
                  background: "rgba(255,255,255,0.1)",
                  color: "#fff",
                  border: "1px solid rgba(255,255,255,0.25)",
                  borderRadius: 10,
                  padding: "13px 28px",
                  fontFamily: FONTS.body,
                  fontSize: 15,
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                I'm new — start here 🌱
              </button>
            </div>
          </div>

          {/* Daily Word Banner */}
          <div
            style={{
              background: COLORS.gold,
              padding: "18px 32px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 16,
              flexWrap: "wrap",
              textAlign: "center",
            }}
          >
            <span style={{ fontFamily: FONTS.body, fontSize: 12, fontWeight: 700, color: COLORS.navy, letterSpacing: "0.1em", textTransform: "uppercase" }}>
              Today's Word
            </span>
            <span style={{ fontFamily: FONTS.display, fontSize: 15, fontWeight: 600, color: COLORS.navy }}>
              "{dailyWord.text}"
            </span>
            <span style={{ fontFamily: FONTS.body, fontSize: 13, fontWeight: 700, color: COLORS.navyLight }}>
              — {dailyWord.reference}
            </span>
          </div>

          {/* Stats row */}
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: 0,
              background: "#fff",
              borderBottom: `1px solid #E5E7EB`,
            }}
          >
            {[
              { label: "Members", value: "12,400+" },
              { label: "Discussions", value: "3,820" },
              { label: "Countries", value: "94" },
              { label: "Replies Today", value: "1,072" },
            ].map((s, i) => (
              <div
                key={i}
                style={{
                  padding: "20px 40px",
                  textAlign: "center",
                  borderRight: i < 3 ? `1px solid #E5E7EB` : "none",
                }}
              >
                <div
                  style={{
                    fontFamily: FONTS.display,
                    fontSize: 24,
                    fontWeight: 700,
                    color: COLORS.navy,
                  }}
                >
                  {s.value}
                </div>
                <div style={{ fontFamily: FONTS.body, fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>

          {/* Featured threads preview */}
          <div style={{ maxWidth: 900, margin: "48px auto", padding: "0 24px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontFamily: FONTS.display, fontSize: 22, fontWeight: 700, color: COLORS.navy, margin: 0 }}>
                Active Discussions
              </h2>
              <button
                onClick={() => setPage("forum")}
                style={{
                  background: "none",
                  border: `1.5px solid ${COLORS.navy}`,
                  color: COLORS.navy,
                  borderRadius: 8,
                  padding: "7px 16px",
                  fontFamily: FONTS.body,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                See all →
              </button>
            </div>
            <div style={{ display: "grid", gap: 14 }}>
              {threads.slice(0, 3).map((t) => (
                <ThreadCard key={t.id} thread={t} onClick={(t) => { setActiveThread(t); setPage("thread"); }} />
              ))}
            </div>
          </div>

          {/* Badges / Levels section */}
          <div style={{ background: COLORS.navy, padding: "56px 32px", textAlign: "center" }}>
            <h2 style={{ fontFamily: FONTS.display, fontSize: 26, fontWeight: 700, color: "#fff", margin: "0 0 10px" }}>
              Grow as you engage
            </h2>
            <p style={{ fontFamily: FONTS.body, fontSize: 15, color: "rgba(255,255,255,0.65)", margin: "0 0 36px" }}>
              Every reply, question, and insight moves you along the journey
            </p>
            <div style={{ display: "flex", justifyContent: "center", gap: 16, flexWrap: "wrap" }}>
              {[
                { label: "Seeker", color: "#A78BFA", desc: "Asking honest questions" },
                { label: "Disciple", color: "#3B82F6", desc: "Consistent learner" },
                { label: "Elder", color: COLORS.gold, desc: "Trusted voice" },
                { label: "Teacher", color: "#EF4444", desc: "Guiding others" },
              ].map((b) => (
                <div
                  key={b.label}
                  style={{
                    background: "rgba(255,255,255,0.07)",
                    border: `1px solid ${b.color}44`,
                    borderRadius: 12,
                    padding: "18px 24px",
                    minWidth: 150,
                  }}
                >
                  <Badge label={b.label} color={b.color} />
                  <p style={{ fontFamily: FONTS.body, fontSize: 13, color: "rgba(255,255,255,0.6)", margin: "10px 0 0" }}>
                    {b.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div style={{ textAlign: "center", padding: "60px 32px" }}>
            <h2 style={{ fontFamily: FONTS.display, fontSize: 28, fontWeight: 700, color: COLORS.navy, margin: "0 0 12px" }}>
              Ready to join the Circle?
            </h2>
            <p style={{ fontFamily: FONTS.body, fontSize: 15, color: COLORS.textMuted, margin: "0 0 28px" }}>
              Free to join. Open to all — whether you've read the Bible for decades or never opened one.
            </p>
            <button
              style={{
                background: COLORS.navy,
                color: "#fff",
                border: "none",
                borderRadius: 10,
                padding: "14px 32px",
                fontFamily: FONTS.body,
                fontSize: 15,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Create your free account
            </button>
          </div>
        </div>
      )}

      {/* ── FORUM PAGE ── */}
      {page === "forum" && (
        <div style={{ maxWidth: 900, margin: "0 auto", padding: "36px 24px" }}>
          <div style={{ marginBottom: 28 }}>
            <h1 style={{ fontFamily: FONTS.display, fontSize: 28, fontWeight: 700, color: COLORS.navy, margin: "0 0 6px" }}>
              The Forum
            </h1>
            <p style={{ fontFamily: FONTS.body, fontSize: 14.5, color: COLORS.textMuted, margin: 0 }}>
              {filteredThreads.length} discussions · Join in, ask freely, share deeply
            </p>
          </div>

          {/* Search + New thread */}
          <div style={{ display: "flex", gap: 10, marginBottom: 22, flexWrap: "wrap" }}>
            <input
              value={searchVal}
              onChange={(e) => setSearchVal(e.target.value)}
              placeholder="Search discussions…"
              style={{
                flex: 1,
                minWidth: 200,
                border: "1.5px solid #D1D5DB",
                borderRadius: 8,
                padding: "10px 14px",
                fontFamily: FONTS.body,
                fontSize: 14,
                color: COLORS.text,
                outline: "none",
                background: "#fff",
              }}
            />
            <button
              style={{
                background: COLORS.navy,
                color: "#fff",
                border: "none",
                borderRadius: 8,
                padding: "10px 20px",
                fontFamily: FONTS.body,
                fontSize: 13.5,
                fontWeight: 600,
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              + Start a Discussion
            </button>
          </div>

          {/* Category tabs */}
          <div style={{ display: "flex", gap: 8, marginBottom: 24, overflowX: "auto", paddingBottom: 4 }}>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                style={{
                  background: activeCategory === cat.id ? COLORS.navy : "#fff",
                  color: activeCategory === cat.id ? "#fff" : COLORS.textMuted,
                  border: `1.5px solid ${activeCategory === cat.id ? COLORS.navy : "#E5E7EB"}`,
                  borderRadius: 20,
                  padding: "6px 16px",
                  fontFamily: FONTS.body,
                  fontSize: 13,
                  fontWeight: 500,
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                  transition: "all 0.15s",
                }}
              >
                {cat.icon} {cat.label}
              </button>
            ))}
          </div>

          {/* Thread list */}
          <div style={{ display: "grid", gap: 14 }}>
            {filteredThreads.length > 0 ? (
              filteredThreads.map((t) => (
                <ThreadCard
                  key={t.id}
                  thread={t}
                  onClick={(t) => {
                    setActiveThread(t);
                    setPage("thread");
                  }}
                />
              ))
            ) : (
              <div style={{ textAlign: "center", padding: "60px 0", color: COLORS.textMuted, fontFamily: FONTS.body }}>
                No discussions found. Be the first to start one ✦
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── THREAD VIEW ── */}
      {page === "thread" && activeThread && (
        <div style={{ maxWidth: 900, margin: "0 auto", padding: "36px 24px" }}>
          <ThreadView thread={activeThread} onBack={() => setPage("forum")} />
        </div>
      )}

      {/* ── FOOTER ── */}
      <footer
        style={{
          background: COLORS.navy,
          color: "rgba(255,255,255,0.5)",
          textAlign: "center",
          padding: "28px 32px",
          fontFamily: FONTS.body,
          fontSize: 13,
          marginTop: 20,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 8 }}>
          <CircleLogo size={22} />
          <span style={{ color: "#fff", fontFamily: FONTS.display, fontWeight: 600 }}>Discussions Exegetica</span>
        </div>
        <p style={{ margin: 0 }}>
          A global biblical discussion community · Free to join · Always open to seekers and believers
        </p>
      </footer>
    </div>
  );
}
