// functions/api/auth.js
// Handles /api/auth/register and /api/auth/login

const BADGE_THRESHOLDS = [
  { badge: 'Teacher',  min: 500 },
  { badge: 'Elder',    min: 100 },
  { badge: 'Disciple', min: 20  },
  { badge: 'Seeker',   min: 0   },
]

export async function onRequestPost({ env, request, params }) {
  const url = new URL(request.url)
  const action = url.pathname.split('/').pop() // 'register' | 'login'

  if (action === 'register') return handleRegister(env, request)
  if (action === 'login')    return handleLogin(env, request)

  return errorResponse('Not found', 404)
}

// ── Register ─────────────────────────────────────────────────

async function handleRegister(env, request) {
  const { username, email, password, display_name } = await request.json()

  if (!username || !email || !password || !display_name)
    return errorResponse('All fields are required')

  if (password.length < 8)
    return errorResponse('Password must be at least 8 characters')

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email))
    return errorResponse('Invalid email address')

  try {
    // Hash password using Web Crypto API (available in Workers)
    const hash = await hashPassword(password)

    // Generate avatar initials
    const initials = display_name
      .split(' ')
      .map(w => w[0])
      .slice(0, 2)
      .join('')
      .toUpperCase()

    const colors = ['#1B2A4A','#7A9E7E','#C9A84C','#2E4270','#4A1B2A']
    const avatar_color = colors[Math.floor(Math.random() * colors.length)]

    const result = await env.DB.prepare(`
      INSERT INTO users (username, email, password_hash, display_name, avatar_initials, avatar_color)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      username.toLowerCase().trim(),
      email.toLowerCase().trim(),
      hash,
      display_name.trim(),
      initials,
      avatar_color
    ).run()

    const token = await generateToken()
    await env.SESSIONS.put(
      `session:${token}`,
      JSON.stringify({ user_id: result.meta.last_row_id, username }),
      { expirationTtl: 60 * 60 * 24 * 30 } // 30 days
    )

    return new Response(
      JSON.stringify({
        success: true,
        token,
        user: { id: result.meta.last_row_id, username, display_name, badge: 'Seeker' }
      }),
      { status: 201, headers: corsHeaders('application/json') }
    )
  } catch (err) {
    if (err.message?.includes('UNIQUE')) {
      return errorResponse('Username or email already taken')
    }
    return errorResponse(err.message, 500)
  }
}

// ── Login ─────────────────────────────────────────────────────

async function handleLogin(env, request) {
  const { email, password } = await request.json()

  if (!email || !password) return errorResponse('Email and password required')

  try {
    const user = await env.DB.prepare(
      `SELECT id, username, display_name, password_hash, badge, avatar_initials, avatar_color
       FROM users WHERE email = ?`
    ).bind(email.toLowerCase().trim()).first()

    if (!user) return errorResponse('Invalid email or password', 401)

    const valid = await verifyPassword(password, user.password_hash)
    if (!valid) return errorResponse('Invalid email or password', 401)

    const token = await generateToken()
    await env.SESSIONS.put(
      `session:${token}`,
      JSON.stringify({ user_id: user.id, username: user.username }),
      { expirationTtl: 60 * 60 * 24 * 30 }
    )

    return new Response(
      JSON.stringify({
        success: true,
        token,
        user: {
          id: user.id,
          username: user.username,
          display_name: user.display_name,
          badge: user.badge,
          avatar_initials: user.avatar_initials,
          avatar_color: user.avatar_color,
        }
      }),
      { headers: corsHeaders('application/json') }
    )
  } catch (err) {
    return errorResponse(err.message, 500)
  }
}

// ── Crypto Helpers ────────────────────────────────────────────

async function hashPassword(password) {
  const encoder = new TextEncoder()
  const salt = crypto.getRandomValues(new Uint8Array(16))
  const saltHex = Array.from(salt).map(b => b.toString(16).padStart(2, '0')).join('')
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    key,
    256
  )
  const hashHex = Array.from(new Uint8Array(bits)).map(b => b.toString(16).padStart(2, '0')).join('')
  return `${saltHex}:${hashHex}`
}

async function verifyPassword(password, stored) {
  const [saltHex, storedHash] = stored.split(':')
  const salt = new Uint8Array(saltHex.match(/.{2}/g).map(b => parseInt(b, 16)))
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    key,
    256
  )
  const hashHex = Array.from(new Uint8Array(bits)).map(b => b.toString(16).padStart(2, '0')).join('')
  return hashHex === storedHash
}

async function generateToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32))
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('')
}

function corsHeaders(contentType) {
  return {
    'Content-Type': contentType,
    'Access-Control-Allow-Origin': '*',
  }
}

function errorResponse(message, status = 400) {
  return new Response(JSON.stringify({ success: false, error: message }), {
    status,
    headers: corsHeaders('application/json'),
  })
}
