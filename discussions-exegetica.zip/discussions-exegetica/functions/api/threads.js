// functions/api/threads.js
// Cloudflare Pages Function — handles /api/threads

export async function onRequestGet({ env, request }) {
  const url = new URL(request.url)
  const category = url.searchParams.get('category')
  const page = parseInt(url.searchParams.get('page') || '1')
  const limit = 20
  const offset = (page - 1) * limit

  try {
    let query = `
      SELECT 
        t.id, t.title, t.body, t.is_pinned, t.view_count,
        t.reply_count, t.like_count, t.created_at,
        u.username, u.display_name, u.avatar_initials,
        u.avatar_color, u.badge,
        c.slug as category_slug, c.label as category_label
      FROM threads t
      JOIN users u ON t.author_id = u.id
      JOIN categories c ON t.category_id = c.id
    `
    const params = []

    if (category && category !== 'all') {
      query += ` WHERE c.slug = ?`
      params.push(category)
    }

    query += ` ORDER BY t.is_pinned DESC, t.updated_at DESC LIMIT ? OFFSET ?`
    params.push(limit, offset)

    const { results } = await env.DB.prepare(query).bind(...params).all()

    return new Response(JSON.stringify({ success: true, threads: results, page, limit }), {
      headers: corsHeaders('application/json'),
    })
  } catch (err) {
    return errorResponse(err.message, 500)
  }
}

export async function onRequestPost({ env, request }) {
  const session = await verifySession(request, env)
  if (!session) return errorResponse('Unauthorised', 401)

  const { title, body, category_slug } = await request.json()
  if (!title?.trim() || !body?.trim() || !category_slug)
    return errorResponse('Missing required fields', 400)

  try {
    const cat = await env.DB.prepare(
      `SELECT id FROM categories WHERE slug = ?`
    ).bind(category_slug).first()

    if (!cat) return errorResponse('Invalid category', 400)

    const result = await env.DB.prepare(`
      INSERT INTO threads (category_id, author_id, title, body)
      VALUES (?, ?, ?, ?)
    `).bind(cat.id, session.user_id, title.trim(), body.trim()).run()

    // Update user reputation
    await env.DB.prepare(
      `UPDATE users SET reputation = reputation + 5 WHERE id = ?`
    ).bind(session.user_id).run()

    return new Response(
      JSON.stringify({ success: true, thread_id: result.meta.last_row_id }),
      { status: 201, headers: corsHeaders('application/json') }
    )
  } catch (err) {
    return errorResponse(err.message, 500)
  }
}

// ── Helpers ──────────────────────────────────────────────────

function corsHeaders(contentType) {
  return {
    'Content-Type': contentType,
    'Access-Control-Allow-Origin': '*',
  }
}

function errorResponse(message, status = 400) {
  return new Response(JSON.stringify({ success: false, error: message }), {
    status,
    headers: corsHeaders('application/json'),
  })
}

async function verifySession(request, env) {
  const token = request.headers.get('Authorization')?.replace('Bearer ', '')
  if (!token) return null
  try {
    const session = await env.SESSIONS.get(`session:${token}`)
    return session ? JSON.parse(session) : null
  } catch {
    return null
  }
}
