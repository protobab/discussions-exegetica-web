// functions/api/daily-word.js
// Returns today's Daily Word for the banner

export async function onRequestGet({ env }) {
  try {
    const today = new Date().toISOString().split('T')[0]

    const word = await env.DB.prepare(
      `SELECT verse_ref, verse_text, theme FROM daily_words WHERE posted_date = ?`
    ).bind(today).first()

    // Fallback to latest if today's not set yet
    const result = word || await env.DB.prepare(
      `SELECT verse_ref, verse_text, theme FROM daily_words ORDER BY posted_date DESC LIMIT 1`
    ).first()

    return new Response(JSON.stringify({ success: true, word: result }), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=3600', // cache 1 hour
      },
    })
  } catch (err) {
    return new Response(JSON.stringify({ success: false, error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    })
  }
}
