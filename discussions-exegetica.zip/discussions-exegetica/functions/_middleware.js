// functions/_middleware.js
// Redirect .org to .com and handle CORS preflight

export async function onRequest({ request, next }) {
  const url = new URL(request.url)

  // Redirect .org to .com
  if (url.hostname === 'discussionsexegetica.org') {
    return Response.redirect(
      `https://discussionsexegetica.com${url.pathname}${url.search}`,
      301
    )
  }

  // Handle CORS preflight
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Max-Age': '86400',
      },
    })
  }

  return next()
}
