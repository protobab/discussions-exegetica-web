import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import HomePage from './pages/HomePage.jsx'
import ForumPage from './pages/ForumPage.jsx'
import ThreadPage from './pages/ThreadPage.jsx'
import NewThreadPage from './pages/NewThreadPage.jsx'
import RegisterPage from './pages/RegisterPage.jsx'
import LoginPage from './pages/LoginPage.jsx'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="forum" element={<ForumPage />} />
          <Route path="forum/:category" element={<ForumPage />} />
          <Route path="thread/:id" element={<ThreadPage />} />
          <Route path="new-thread" element={<NewThreadPage />} />
          <Route path="register" element={<RegisterPage />} />
          <Route path="login" element={<LoginPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
