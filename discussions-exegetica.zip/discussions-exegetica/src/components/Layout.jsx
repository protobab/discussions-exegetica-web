// src/components/Layout.jsx
import { Outlet, Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth.js'
import { COLORS, FONTS } from '../lib/tokens.js'
import CircleLogo from './CircleLogo.jsx'

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const navLinks = [
    { label: 'Home',         to: '/' },
    { label: 'Forum',        to: '/forum' },
    { label: 'Daily Word',   to: '/forum/exegesis' },
    { label: 'Study Groups', to: '/forum' },
  ]

  return (
    <div style={{ fontFamily: FONTS.body, background: COLORS.parchment, minHeight: '100vh' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        a { text-decoration: none; color: inherit; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-thumb { background: ${COLORS.gold}88; border-radius: 3px; }
      `}</style>

      {/* NAV */}
      <nav style={{
        background: COLORS.navy,
        padding: '0 32px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 60,
        position: 'sticky',
        top: 0,
        zIndex: 100,
        boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
      }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <CircleLogo size={32} />
          <span style={{ fontFamily: FONTS.display, fontSize: 18, fontWeight: 700, color: '#fff' }}>
            Discussions <span style={{ color: COLORS.gold }}>Exegetica</span>
          </span>
        </Link>

        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          {navLinks.map(({ label, to }) => (
            <Link
              key={label}
              to={to}
              style={{
                color: 'rgba(255,255,255,0.75)',
                fontFamily: FONTS.body,
                fontSize: 13.5,
                fontWeight: 500,
                padding: '6px 14px',
                borderRadius: 6,
              }}
            >
              {label}
            </Link>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {user ? (
            <>
              <span style={{ color: COLORS.gold, fontFamily: FONTS.body, fontSize: 13.5, fontWeight: 600 }}>
                {user.display_name}
              </span>
              <button
                onClick={logout}
                style={{
                  background: 'rgba(255,255,255,0.1)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  color: '#fff',
                  borderRadius: 8,
                  padding: '7px 14px',
                  fontFamily: FONTS.body,
                  fontSize: 13,
                  cursor: 'pointer',
                }}
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" style={{
                color: 'rgba(255,255,255,0.75)',
                fontFamily: FONTS.body,
                fontSize: 13.5,
                fontWeight: 500,
                padding: '7px 14px',
              }}>
                Sign in
              </Link>
              <Link to="/register" style={{
                background: COLORS.gold,
                color: COLORS.navy,
                borderRadius: 8,
                padding: '8px 18px',
                fontFamily: FONTS.body,
                fontSize: 13,
                fontWeight: 700,
              }}>
                Join Now
              </Link>
            </>
          )}
        </div>
      </nav>

      {/* PAGE CONTENT */}
      <main>
        <Outlet />
      </main>

      {/* FOOTER */}
      <footer style={{
        background: COLORS.navy,
        color: 'rgba(255,255,255,0.5)',
        textAlign: 'center',
        padding: '28px 32px',
        fontFamily: FONTS.body,
        fontSize: 13,
        marginTop: 40,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 8 }}>
          <CircleLogo size={22} />
          <span style={{ color: '#fff', fontFamily: FONTS.display, fontWeight: 600 }}>Discussions Exegetica</span>
        </div>
        <p>A global biblical discussion community · Free to join · Always open to seekers and believers</p>
        <p style={{ marginTop: 8 }}>
          <Link to="/forum" style={{ color: COLORS.gold, marginRight: 16 }}>Forum</Link>
          <a href="mailto:hello@discussionsexegetica.com" style={{ color: COLORS.gold }}>Contact</a>
        </p>
      </footer>
    </div>
  )
}
