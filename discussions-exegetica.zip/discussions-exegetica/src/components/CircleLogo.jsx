// src/components/CircleLogo.jsx
import { COLORS } from '../lib/tokens.js'

export default function CircleLogo({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none">
      <circle cx="18" cy="18" r="16" stroke={COLORS.gold} strokeWidth="2" />
      <circle cx="18" cy="18" r="9" stroke={COLORS.gold} strokeWidth="1.5" strokeDasharray="3 2" />
      <circle cx="18" cy="18" r="3.5" fill={COLORS.gold} />
      <path d="M18 2 A16 16 0 0 1 34 18" stroke={COLORS.goldLight} strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  )
}
