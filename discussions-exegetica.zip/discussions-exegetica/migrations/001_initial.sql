-- ============================================================
--  Discussions Exegetica — Database Schema
--  Migration: 001_initial.sql
-- ============================================================

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  username    TEXT NOT NULL UNIQUE,
  email       TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  bio         TEXT DEFAULT '',
  avatar_initials TEXT DEFAULT '',
  avatar_color TEXT DEFAULT '#1B2A4A',
  badge       TEXT DEFAULT 'Seeker',   -- Seeker | Disciple | Elder | Teacher
  reputation  INTEGER DEFAULT 0,
  verified    INTEGER DEFAULT 0,       -- 0=unverified, 1=verified
  is_admin    INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now')),
  updated_at  TEXT DEFAULT (datetime('now'))
);

-- CATEGORIES
CREATE TABLE IF NOT EXISTS categories (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  icon        TEXT DEFAULT '✦',
  description TEXT DEFAULT '',
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now'))
);

-- THREADS
CREATE TABLE IF NOT EXISTS threads (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL REFERENCES categories(id),
  author_id   INTEGER NOT NULL REFERENCES users(id),
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  is_pinned   INTEGER DEFAULT 0,
  is_locked   INTEGER DEFAULT 0,
  view_count  INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  like_count  INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now')),
  updated_at  TEXT DEFAULT (datetime('now'))
);

-- REPLIES
CREATE TABLE IF NOT EXISTS replies (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id   INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  author_id   INTEGER NOT NULL REFERENCES users(id),
  parent_id   INTEGER REFERENCES replies(id),  -- for nested replies
  body        TEXT NOT NULL,
  like_count  INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now')),
  updated_at  TEXT DEFAULT (datetime('now'))
);

-- LIKES (threads)
CREATE TABLE IF NOT EXISTS thread_likes (
  user_id     INTEGER NOT NULL REFERENCES users(id),
  thread_id   INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  created_at  TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, thread_id)
);

-- LIKES (replies)
CREATE TABLE IF NOT EXISTS reply_likes (
  user_id     INTEGER NOT NULL REFERENCES users(id),
  reply_id    INTEGER NOT NULL REFERENCES replies(id) ON DELETE CASCADE,
  created_at  TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, reply_id)
);

-- DAILY WORD
CREATE TABLE IF NOT EXISTS daily_words (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  verse_ref   TEXT NOT NULL,          -- e.g. "John 1:1"
  verse_text  TEXT NOT NULL,
  theme       TEXT DEFAULT '',
  posted_date TEXT NOT NULL UNIQUE,   -- YYYY-MM-DD
  created_at  TEXT DEFAULT (datetime('now'))
);

-- STUDY GROUPS
CREATE TABLE IF NOT EXISTS study_groups (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  description TEXT DEFAULT '',
  owner_id    INTEGER NOT NULL REFERENCES users(id),
  is_public   INTEGER DEFAULT 1,
  member_count INTEGER DEFAULT 1,
  created_at  TEXT DEFAULT (datetime('now'))
);

-- STUDY GROUP MEMBERS
CREATE TABLE IF NOT EXISTS study_group_members (
  group_id    INTEGER NOT NULL REFERENCES study_groups(id) ON DELETE CASCADE,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  role        TEXT DEFAULT 'member',  -- owner | moderator | member
  joined_at   TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (group_id, user_id)
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_threads_category ON threads(category_id);
CREATE INDEX IF NOT EXISTS idx_threads_author ON threads(author_id);
CREATE INDEX IF NOT EXISTS idx_threads_created ON threads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_replies_thread ON replies(thread_id);
CREATE INDEX IF NOT EXISTS idx_replies_author ON replies(author_id);
CREATE INDEX IF NOT EXISTS idx_daily_words_date ON daily_words(posted_date DESC);
