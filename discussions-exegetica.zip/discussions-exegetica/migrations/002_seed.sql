-- ============================================================
--  Discussions Exegetica — Seed Data
--  Migration: 002_seed.sql
-- ============================================================

-- CATEGORIES
INSERT OR IGNORE INTO categories (slug, label, icon, description, sort_order) VALUES
  ('exegesis',  'Deep Dive',       '📖', 'Verse-by-verse and word-by-word biblical studies', 1),
  ('seekers',   'Seekers Corner',  '🌱', 'A safe space for honest questions — no wrong questions here', 2),
  ('prayer',    'Prayer & Life',   '🙏', 'Faith in daily life, prayer, and Christian living', 3),
  ('prophecy',  'Prophecy',        '🕊️', 'Biblical prophecy, Messianic texts, and fulfilment', 4),
  ('theology',  'Theology',        '⚡', 'Doctrine, systematic theology, and apologetics', 5),
  ('resources', 'Resources',       '📚', 'Commentaries, tools, sermons, and study aids', 6);

-- DAILY WORDS (first week)
INSERT OR IGNORE INTO daily_words (verse_ref, verse_text, theme, posted_date) VALUES
  ('John 1:1',      'In the beginning was the Word, and the Word was with God, and the Word was God.',                                           'The Nature of Christ',      date('now')),
  ('Psalm 119:105', 'Your word is a lamp to my feet and a light to my path.',                                                                    'Scripture as Guide',        date('now', '+1 day')),
  ('Hebrews 4:12',  'For the word of God is living and active, sharper than any two-edged sword.',                                               'The Power of Scripture',    date('now', '+2 days')),
  ('Romans 10:17',  'So faith comes from hearing, and hearing through the word of Christ.',                                                       'Faith and the Word',        date('now', '+3 days')),
  ('Isaiah 40:8',   'The grass withers, the flower fades, but the word of our God will stand forever.',                                          'Eternal Truth',             date('now', '+4 days')),
  ('2 Timothy 3:16','All Scripture is breathed out by God and profitable for teaching, for reproof, for correction, and for training in righteousness.', 'Inspiration of Scripture', date('now', '+5 days')),
  ('Matthew 5:3',   'Blessed are the poor in spirit, for theirs is the kingdom of heaven.',                                                      'The Beatitudes',            date('now', '+6 days'));
